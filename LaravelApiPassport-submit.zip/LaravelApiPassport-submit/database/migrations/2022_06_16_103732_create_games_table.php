<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('games', function (Blueprint $table) {
            $table->integer('id');
            $table->integer('dice_one');
            $table->integer('dice_two');
            $table->integer('result');
            $table->integer('points');
            $table->integer('ranking');
            $table->integer('lowest_ranking');
            $table->integer('highest_ranking');
            $table->foreignId('user_id'); //->references('id')->on('users');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('game');
    }
};
